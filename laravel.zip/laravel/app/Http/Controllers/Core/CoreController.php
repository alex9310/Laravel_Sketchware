<?php

namespace App\Http\Controllers\Core;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Core;
//создаем запрос json
class CoreController extends Controller
{
    public function index() {
      return response()->json(Core::get(), 200);
    }
}
