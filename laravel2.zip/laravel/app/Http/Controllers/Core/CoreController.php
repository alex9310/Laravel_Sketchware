<?php

namespace App\Http\Controllers\Core;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Core;
//создаем запрос json
class CoreController extends Controller
{
    public function index() {
      return response()->json(Core::get(), 200);
    }
    
    public function info($id) {
      return response()->json(Core::find($id), 200);
    }
    
    public function save(Request $req) {
      $core = Core::create($req->all());
      return response()->json($core, 201);
    }
    public function edit(Request $req, Core $core) {
      $core->update($req->all());
      return response()->json($core, 200);
    }
    public function delete(Request $req, Core $core) {
      $core->delete();
      return response()->json('', 204);
    }
}
