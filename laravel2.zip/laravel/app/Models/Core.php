<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
//для база данных, чтобы вывести в json
class Core extends Model
{
    protected $table = "test";
    
    public $timestamps = false;
    
    protected $fillable = [
      "id",
      "name",
      "post",
      "author" ];
}
