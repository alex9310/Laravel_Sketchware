<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Core;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

//Мы указываем путь api/core
Route::get('core', [Core\CoreController::class, 'index']);
//ищем именнл по id, чтобы посмотреть например core/1
Route::get('core/{id}', [Core\CoreController::class, 'info']);
//Мы отправляем базу данных,  т.е мы добавляем запись!=)
Route::post('core', [Core\CoreController::class, 'save']);
// Мы изменяем запись
Route::put('core/{core}', [Core\CoreController::class, 'edit']);
//ямы удаляем запись из id
Route::delete('core/{core}', [Core\CoreController::class, 'delete']);